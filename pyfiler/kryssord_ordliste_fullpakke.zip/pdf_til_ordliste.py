# -*- coding: utf-8 -*-
"""
PDF → OrdListe (Norsk)
----------------------
- Leser tekst fra én eller flere PDF-filer (pdfplumber)
- Rydder tekst (fjerner soft hyphen, orddeling -\n, normaliserer mellomrom)
- Ekstraherer ord (A–Z + ÆØÅ) i UPPERCASE
- Valgfritt: filtrerer norske stop-ord
- Skriver TXT (ORD\tFREKVENS\tLENGDE) og/eller XLSX (3 ark)
- (Valgfritt) OCR-fallback med pytesseract/pdf2image hvis ingen tekstlag (krever ekstra installasjon)

Bruk:
    python pdf_til_ordliste.py fil1.pdf [fil2.pdf ...] --skriv-txt --skriv-xlsx --stop-ord --min-lengde 2
    python pdf_til_ordliste.py fil.pdf --ocr-fallback  # prøv OCR hvis ingen tekst

Avhengigheter (grunnleggende):
    pip install pdfplumber pandas openpyxl

OCR (kun ved behov):
    pip install pytesseract pdf2image pillow
    + installer Tesseract på systemet og POPPLER (for pdf2image)
"""

import argparse
import re
from pathlib import Path
from collections import Counter
import sys

import pdfplumber
import pandas as pd

# -------------------------
# Norske stoppord (enkelt sett, kan utvides)
# -------------------------
NORSKE_STOPPORD = set("""
OG ER EN ET EI DET DEN DE DU DERE DERES DIN DINE JEG VI VÅR VÅRT VÅRE
PÅ AV FOR FRA I TIL MOT MED SOM MEN OGSÅ OM Å DA NÅ ELLER HVOR HVEM HVA
SÅ SIN SITT SINE DITT DER DA HER DERFOR HOS BLIR VED INN UT OVER UNDER
""".split())


def normaliser_tekst(t: str) -> str:
    if not t:
        return ""
    t = t.replace("\u00AD", "")                     # soft hyphen
    t = re.sub(r"-\s*\n", "", t)                   # orddeling
    t = t.replace("\r", "\n")
    t = re.sub(r"\n+", " ", t)
    t = re.sub(r"\s+", " ", t).strip()
    return t


def les_pdf_tekst(pdf_path: Path) -> str:
    tekst_biter = []
    with pdfplumber.open(str(pdf_path)) as pdf:
        for side in pdf.pages:
            t = side.extract_text() or ""
            tekst_biter.append(t)
    return "\n".join(tekst_biter)


def ocr_pdf_tekst(pdf_path: Path, lang: str = "nor") -> str:
    """OCR: Konverter hver side til bilde og kjør Tesseract. Krever pytesseract, pdf2image, pillow.
    Returnerer tom streng hvis avhengigheter mangler.
    """
    try:
        from pdf2image import convert_from_path
        import pytesseract
    except Exception as e:
        print("[OCR] Mangler avhengigheter (pytesseract/pdf2image). Installer for OCR.")
        return ""

    try:
        bilder = convert_from_path(str(pdf_path))
    except Exception as e:
        print(f"[OCR] Kunne ikke konvertere PDF til bilder: {e}")
        return ""

    tekst_biter = []
    for img in bilder:
        try:
            s = pytesseract.image_to_string(img, lang=lang) or ""
            tekst_biter.append(s)
        except Exception as e:
            print(f"[OCR] Feil ved OCR: {e}")
    return "\n".join(tekst_biter)


def ekstraher_ord(t: str, min_len: int = 2, stoppord: bool = False):
    if not t:
        return []
    t_upper = t.upper()
    tokens = re.findall(r"[A-ZÆØÅ]+", t_upper)
    tokens = [w for w in tokens if len(w) >= min_len]
    if stoppord:
        tokens = [w for w in tokens if w not in NORSKE_STOPPORD]
    return tokens


def behandle_pdf(pdf_path: Path, min_len: int, stoppord: bool, skriv_txt: bool, skriv_xlsx: bool, ocr_fallback: bool):
    print(f"Leser: {pdf_path}")
    tekst = normaliser_tekst(les_pdf_tekst(pdf_path))

    # OCR fallback hvis ingen tekst og flagget er satt
    if not tekst and ocr_fallback:
        print("Ingen tekstlag funnet. Forsøker OCR (kan ta tid)...")
        tekst = normaliser_tekst(ocr_pdf_tekst(pdf_path))

    ordliste = ekstraher_ord(tekst, min_len=min_len, stoppord=stoppord)
    c = Counter(ordliste)

    base = pdf_path.with_suffix("")
    out_txt = base.parent / f"{base.name}_ordliste.txt"
    out_xlsx = base.parent / f"{base.name}_ordliste.xlsx"

    if skriv_txt:
        with open(out_txt, "w", encoding="utf-8") as f:
            f.write("ORD\tFREKVENS\tLENGDE\n")
            for w in sorted(c.keys()):
                f.write(f"{w}\t{c[w]}\t{len(w)}\n")
        print(f"→ Skrev TXT: {out_txt}")

    if skriv_xlsx:
        df = pd.DataFrame({
            "Ord": list(c.keys()),
            "Frekvens": [c[w] for w in c],
            "Lengde": [len(w) for w in c]
        })
        # tom fil med headere om ingen ord
        if df.empty:
            df = pd.DataFrame(columns=["Ord", "Frekvens", "Lengde"])
            with pd.ExcelWriter(out_xlsx, engine="openpyxl") as xw:
                df.to_excel(xw, index=False, sheet_name="A-Å")
            print(f"→ Skrev tom XLSX med headere: {out_xlsx}")
        else:
            df_alpha = df.sort_values(["Ord"]).reset_index(drop=True)
            df_len = df.sort_values(["Lengde", "Ord"]).reset_index(drop=True)
            df_freq = df.sort_values(["Frekvens", "Ord"], ascending=[False, True]).reset_index(drop=True)
            with pd.ExcelWriter(out_xlsx, engine="openpyxl") as xw:
                df_alpha.to_excel(xw, index=False, sheet_name="A-Å")
                df_len.to_excel(xw, index=False, sheet_name="Lengde")
                df_freq.to_excel(xw, index=False, sheet_name="Frekvens")
            print(f"→ Skrev XLSX: {out_xlsx}")

    print(f"  Totalt ord: {sum(c.values())}, unike: {len(c)}\n")


def main(argv=None):
    ap = argparse.ArgumentParser(description="PDF → OrdListe (TXT/XLSX)")
    ap.add_argument("pdf", nargs="+", type=Path, help="Én eller flere PDF-filer")
    ap.add_argument("--min-lengde", type=int, default=2, help="Minste ordlengde")
    ap.add_argument("--stop-ord", action="store_true", help="Fjern norske stop-ord")
    ap.add_argument("--skriv-txt", action="store_true", help="Lag TXT (ORD\tFREKVENS\tLENGDE)")
    ap.add_argument("--skriv-xlsx", action="store_true", help="Lag XLSX (3 ark)")
    ap.add_argument("--ocr-fallback", action="store_true", help="Bruk OCR hvis PDF mangler tekstlag (krever ekstra installasjon)")
    args = ap.parse_args(argv)

    for p in args.pdf:
        if not p.exists():
            print(f"Advarsel: Finner ikke {p}", file=sys.stderr)
            continue
        behandle_pdf(p, args.min_lengde, args.stop_ord, args.skriv_txt, args.skriv_xlsx, args.ocr_fallback)


if __name__ == "__main__":
    main()
