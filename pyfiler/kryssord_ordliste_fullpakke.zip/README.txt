Kryssord Ordlistemotor (Norsk)
==============================

Innhold:
  - pdf_til_ordliste.py  (Python-scriptet)
  - kryssord_ordliste.bat (Windows dra-og-slipp)
  - requirements.txt     (avhengigheter)

Krav:
  - Windows med Python 3.10+ installert og i PATH (installer fra python.org)
  - Ingen ekstra krav for vanlige PDF-er som har tekstlag
  - (Valgfritt) OCR: pytesseract, pdf2image, pillow + Tesseract/Poppler installert

Bruk (enklest):
  1) Legg alle tre filene i samme mappe
  2) Dra én eller flere PDF-er over kryssord_ordliste.bat
  3) Resultater (ved siden av hver PDF):
        <fil>_ordliste.txt      (ORD\tFREKVENS\tLENGDE)
        <fil>_ordliste.xlsx     (ark: A-Å, Lengde, Frekvens)

Alternativ (kommandolinje):
  pip install -r requirements.txt
  python pdf_til_ordliste.py min.pdf --skriv-txt --skriv-xlsx --stop-ord

OCR ved behov (skannede PDF-er uten tekstlag):
  pip install pytesseract pdf2image pillow
  (Installer Tesseract og Poppler på systemet.)
  python pdf_til_ordliste.py min.pdf --skriv-txt --ocr-fallback

Tips:
  - Endre --min-lengde hvis du vil inkludere 1-bokstavs ord
  - Fjern --stop-ord i BAT dersom du vil ha en komplett råliste
  - Hvis filer ikke åpnes automatisk: fjern/kommenter START-linjene i .bat
